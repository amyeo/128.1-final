# Util Pack

A collection of utilities that can be comined to create a starting point or micro framework to work off. Follow the instructions below.

Options:

- Copy each of the desired files one by one to your project, or 
- Copy the code of each file into the util.pack.js file and use that in your project

All code is framework agnostic unless noted.