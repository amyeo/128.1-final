﻿# Utilities Changelog

# v0.9 / In development
- Added `Array.prototype.inArray()`
- Added checking for IE9 and chrome to `browser`
- Changed `embed()` to only take one param and return code all the time
- Renamed `scroll_position()` to `scrollPosition()`
- Renamed `in_array()` to `inArray()`
- Renamed `http.add_param()` to `http.addParam()`
- Renamed `http.get_hash()` to `http.getHash()`
- Renamed `http.get_params()` to `http.getParams()`
- Renamed `debug` object to `dbug`
- Moved `util.typeOf()` to `typeOf()`
- Moved `util.source()` to `dbug.source()`