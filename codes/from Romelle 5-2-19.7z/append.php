<?php

	//from form 1
	$skill_count = $_POST['skill_count'];
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$middle_initial = $_POST['middle_initial'];
	$sex = $_POST['sex'];
	$full_address = $_POST['full_address'];
	$place_of_birth = $_POST['place_of_birth'];
	$birthday = $_POST['birthday'];
	$phone_number = $_POST['phone_number'];
	$email = $_POST['email'];
	$linkedin_profile = $_POST['linkedin_profile'];
	$educational_attainment = $_POST['educational_attainment'];
	$civil_status = $_POST['civil_status'];
	$nationality = $_POST['nationality'];
	$SSN = $_POST['SSN'];
	$employee_skill_1 = $_POST['employee_skill_1'];
	if($skill_count>1)
	$employee_skill_2 = $_POST['employee_skill_2'];
	if($skill_count>2)
	$employee_skill_3 = $_POST['employee_skill_3'];
	if($skill_count>3)
	$employee_skill_4 = $_POST['employee_skill_4'];
	if($skill_count>4)
	$employee_skill_5 = $_POST['employee_skill_5'];
	$applying_for = $_POST['applying_for'];
	$birth_cert_id = $_POST['birth_cert_id'];
	$health_benefits = $_POST['health_benefits'];
	


?>